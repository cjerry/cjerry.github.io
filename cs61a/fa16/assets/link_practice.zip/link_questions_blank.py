from link import *

def reverse(lnk):
    """
    Reverse a linked list in place.
    >>> lnk = Link(1, Link(2, Link(3)))
    >>> new_head = reverse(lnk)
    >>> new_head
    Link(3, Link(2, Link(1)))
    >>> lnk
    Link(1)
    """
    """***Your solution here***"""

def reverse_first_n(lnk, n):
    """
    Reverse first n items in a linked list.
    >>> lnk = Link(1, Link(2, Link(3)))
    >>> new_head = reverse_first_n(lnk, 2)
    >>> new_head
    Link(2, Link(1, Link(3)))
    >>> lnk
    Link(1, Link(3))
    >>> new_head = reverse_first_n(new_head, 3)
    >>> new_head
    Link(3, Link(1, Link(2)))
    """
    """***Your solution here***"""

def reverse_i_to_j(lnk, i, j):
    """
    Reverse from indices i to j.
    >>> lnk = Link(1, Link(2, Link(3, Link(4))))
    >>> reverse_i_to_j(lnk, 1, 3)
    Link(1, Link(3, Link(2, Link(4))))
    """
    """***Your solution here***"""

def reverse_from_n(lnk, n):
    """
    Reverse all items in the linked list after the first occurrence of n.
    >>> lnk = Link(4, Link(5, Link(6, Link(7))))
    >>> reverse_from_n(lnk, 4)
    >>> lnk
    Link(4, Link(7, Link(6, Link(5))))
    >>> lnk_2 = Link(4, Link(5, Link(6, Link(7))))
    >>> reverse_from_n(lnk_2, 5)
    >>> lnk_2
    Link(4, Link(5, Link(7, Link(6))))
    """
    """***Your solution here***"""
