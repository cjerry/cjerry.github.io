from btree import *

def smallest(bt):
    """
    Return the smallest value in the bst.
    >>> bt = bst([1, 3, 4, 5, 10, 15, 30, 40])
    >>> smallest(bt)
    1
    >>> smallest(BTree(5, BTree(2), BTree(7)))
    2
    """
    """***Your solution here***"""

def closest(bt, val):
    """
    Find the closest value in the bt to val.

    >>> bt = bst([1, 3, 4, 5, 10, 15, 30, 40])
    >>> closest(bt, 10)
    10
    >>> closest(bt, 50)
    40
    >>> closest(bt, 13)
    15
    >>> closest(BTree.empty, 9232)
    0
    """
    """***Your solution here***"""
