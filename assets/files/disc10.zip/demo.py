# Iterators/Iterables
class Ordering(object):
    def __init__(self, n):
        self.n = n

    def __next__(self):
        print("Calling next")
        if self.n <= 0:
            print("No more items")
            raise StopIteration
        ret = self.n
        self.n -= 1
        return ret

    def __iter__(self):
        print("Calling iter")
        return self


# Generators
def ordering(n):
    while n > 0:
        print("Before yield")
        yield n
        print("After yield")
        n -= 1
