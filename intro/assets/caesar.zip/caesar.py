def shift_letter(letter, amt):
    """
    Shifts a letter right by a given amount.

    Hint: Here is how to shift the letter 'a' right by 1:
    >>> chr(ord('a') + 1)
    'b'

    >>> shift_letter('a', 1)
    'b'
    >>> shift_letter('b', 10)
    'l'
    >>> shift_letter('A', 2)
    'C'
    """
    """***REPLACE WITH YOUR CODE***"""

# If we want to wrap around, use this instead. Make sure to replace shift_letter
# in caesar_encode with shift_letter_wrapping if you want to use it!
def shift_letter_wrapping(letter, amt):
    """
    Shifts a letter right by a given amount, wrapping if we go below 'A' or 'a'
    or if we go past 'Z' or 'z'.

    This is optional!

    >>> shift_letter_wrapping('a', 2) # Regular wrapping should work still.
    'c'
    >>> shift_letter_wrapping('z', 1)
    'a'
    >>> shift_letter_wrapping('a', -1)
    'z'
    >>> shift_letter_wrapping('Z', 1)
    'A'
    >>> shift_letter_wrapping('A', -1)
    'Z'
    """
    # Reminder: This function is optional!
    """***REPLACE WITH YOUR CODE***"""

def caesar_encode(text, shift):
    """
    Takes in text to encode and right shift amount. Returns the text encoded
    using the Caesar cipher.

    >>> caesar_encode('abc', 0)
    'abc'
    >>> caesar_encode('reverse', -2) # A negative value is a left shift!
    'pctcpqc'
    >>> caesar_encode('JuliusCaesar', 4) # Spaces will behave a bit oddly.
    'NypmywGeiwev'
    >>> caesar_encode('Therearesnakes', 3)
    'Wkhuhduhvqdnhv'

    # Uncomment this if you implemented shift_letter_wrapping.
    # >>> caesar_encode('EECS', 16)
    # 'UUSI'
    """
    encoded_string = ''
    for letter in text:
        encoded_string += _____________
    return _____________

def caesar_decode(encoded_text, original_shift):
    """
    Takes in text to DECODE and the amount it was ORIGINALLY shifted. Returns
    the original, decoded text.

    >>> caesar_decode('abc', 0)
    'abc'
    >>> caesar_decode('reverse', 2) # Original right 2, shift left 2 to decode.
    'pctcpqc'
    >>> caesar_decode(caesar_encode('There are snakes', 2), 2)
    'There are snakes'
    """
    # This is doable in one line.
    # Hint: look at the second doctest for this function.
    return _______________________
