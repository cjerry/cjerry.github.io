# You are not required to read or understand this file.
from caesar import caesar_encode
from caesar import caesar_decode

def cipher():
    print("Shift amount")
    shift = int(input())
    print("Text to encode or decode")
    text = input()

    while True:
        print("Do you want to encode or decode? Enter E or D")
        response = input()
        if response == "E":
            print(caesar_encode(text, shift))
            return
        elif response == "D":
            print(caesar_decode(text, shift))
            return


cipher()

