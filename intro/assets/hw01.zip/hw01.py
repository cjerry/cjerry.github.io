def print_me(phrase):
    """Print a given phrase.

    >>> print_me("Hello world")
    Hello world
    >>> print_me("Coding is fun")
    Coding is fun
    """
    "***YOUR CODE HERE***"


def print_and_return_me(phrase):
    """Print AND return a given phrase.

    >>> print_and_return_me("Hello world")
    Hello world
    'Hello world'
    >>> 10 + print_and_return_me(10)
    10
    20
    """
    "***YOUR CODE HERE***"


def plus_twenty(n):
    """Add 20 to n.

    >>> plus_twenty(10)
    30
    >>> plus_twenty(20)
    40
    >>> x = plus_twenty(30)
    >>> x
    50
    """
    "***YOUR CODE HERE***"
